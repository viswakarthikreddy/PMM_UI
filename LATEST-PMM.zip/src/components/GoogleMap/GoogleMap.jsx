import React, { Component } from 'react';
import { Map, TileLayer as Basemap } from 'react-leaflet';
import carto from 'carto.js';
import Layer from './Layer';
import airbnb  from '../../data/airbnb';
import { MapWrapper } from './GoogleMapStyle';

const CARTO_BASEMAP = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}.png';

class GoogleMap extends Component {
  state = {
    center: [40.42, -3.7],
    zoom: 3,
    nativeMap: undefined,
    layerStyle: airbnb.style,
    hidelayers: false
  }

  cartoClient = new carto.Client({ apiKey: '087c29e87e7e8fc82e70c8b1b5b72ab2eed76fbf', username: 'viswakarthikreddy' });

  componentDidMount() {
    this.setState({ nativeMap: this.nativeMap });
  }

  

  render() {
    const { center, nativeMap, zoom } = this.state;

    return (
      <MapWrapper>
        <Map center={center} zoom={zoom} style={{height: "100%" }} ref={node => { this.nativeMap = node && node.leafletElement }}>
          <Basemap attribution="" url={CARTO_BASEMAP} />

          <Layer
            source={airbnb.source}
            style={this.state.layerStyle}
            client={this.cartoClient}
            hidden={this.state.hidelayers}
          />
        </Map>

        
      </MapWrapper>
    );
  }


}

export default GoogleMap;
