import styled from 'styled-components';

export const NotificationWrapper = styled.div`
    background: #a20067;
    padding: 10px 0;
    color: #fff;
`;