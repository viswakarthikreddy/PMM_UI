import React from 'react';

const AnalysisContainer = () => {
    return (
        <div>
         Analysis
        </div>
    );
}

export default AnalysisContainer;