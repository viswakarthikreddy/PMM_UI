import React from 'react';

const UsersContainer = () => {
    return (
        <>
           Users
        </>
    );
}

export default UsersContainer;