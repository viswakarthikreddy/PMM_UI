export const routes = [
    {
        path: '/explore',
        label: 'Explore'
    },
    {
        path: '/analysis',
        label: 'Analysis'
    },
    {
        path: '/users',
        label: 'Users'
    }
]